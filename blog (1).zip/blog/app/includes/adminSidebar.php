<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/admin/posts/index.php'?>">Manage Organizations</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/users/index.php'?>">Manage Users</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/topics/index.php'?>">Manage Satellites</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/admins/index.php'?>">Manage Admins</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/clients/index.php'?>">Manage Clients</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/supplier/index.php'?>">Manage Suppliers</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/projects/index.php'?>">Manage Projects</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/country/index.php'?>">Manage Countries</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/centers/index.php'?>">Manage Organisation Centers</a></li>
    </ul>
</div>